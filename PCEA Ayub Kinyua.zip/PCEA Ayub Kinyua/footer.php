<link rel="stylesheet" href="style.css" type="text/css"/>
<div id="footer">
<p align="center">&copy; PCEA GITHUNGURI PARISH 2016</p>
</div>
  
 