<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Boys&Girls Brigade::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">

<br>
 
	 <p>&nbsp;</p>
<div id="inner_cont">
<fieldset><legend>
The Boys&amp;Girls Brigade</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">
<li>Chairman	-	Joseph Mburu Waweru</li>
<li>Secretary	-	Dorcas Wanjiru Kanyua</li>
<li>Treasurer	-	Margaret Muchina</li>
<li>V/ Chairperson	-	Agnes Kahuha</li>
<li>V/Secretary	-	Lewis Kaburunje</li>
&nbsp;
&nbsp;
The boys and girls brigade is the stage succeeding the Church School.Here the membership is open to every agegroup.The soul purpose of this group is to serve and commitment to help in the community in God.Brigade is the most fun group that one would join.Discipline is the core of this group.<br>
The Parish Boys &amp; Girls Brigade boasts of 65 Brigaders, one National trainer and 15 trained officers. They were actively involved in various activities in the just concluded church year 2014/15. 

</fieldset>



<hr />

</div>
<br>
<br>
</div>

<?php
include "footer.php"
?>
</body>

</html>