<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>projects</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function mouseOver()
{
document.b1.src ="images/2.jpg";
}
function mouseOut()
{
document.b1.src ="images/5.jpg";
}
</script>

</head>

<body>


<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>

<div id="pageContent">


<div id="inner_cont">
<br>
<fieldset><legend>Secondary School project</legend>


<img border="0" alt=""
src="images/1.jpg" name="b1"
onmouseOver="mouseOver()"
onmouseOut="mouseOut()"  height="250px" weight="250px"/>
<br>
P.C.E.A. Githunguri Township High School:  The institution is a mixed secondary school which was started in February, 2013 with 10 students but currently has 106 students in form 1, 2 and 3 with a pioneer Form Four/Candidate class in 2016.  There are six members of staff with a principal and his deputy that run it. It has also engaged a cook and a cleaner. The church is actively involved in the running of the institution. The church is actively involved in the running of the school with members of the school Board of Management drawn from it

</fieldset>


</div>

<br>
</div>

<?php
include "footer.php"
?>


</body>

</html>