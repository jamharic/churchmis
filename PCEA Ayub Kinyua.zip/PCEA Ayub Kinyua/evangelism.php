<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Evangelism::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">

<br>
 
<p>&nbsp;</p>
<div id="inner_cont">
<fieldset><legend>Education comittee</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>

<ul type="square">
<li>Chairman	-	John Kaguma Nguku</li> 
<li>Secretary	-	Ev. Margaret Nyakiringa Mwangi</li>
<li>Treasurer	- 	Peter Mbiyu Kamitha</li>
<li>V/Chairman	-	Michael Kiritu Kamau</li>
<li>V/Secretary	-	Damaris Wambui Mwaniki</li>

<ul>
&nbsp;
&nbsp;
	At least two members from each district form the Parish Evangelism team.;
	This team held two missions {December 2014 &amp; April 2015} and a convention in August 2015;
	During this time, the team, other Parish members and invited missioners engaged in door to door evangelism;
	Additionally, Crusades were held next to Diplomat house every evening of the Evangelism week usually running from Tuesday through Sunday at such times,

.</fieldset>
<p>&nbsp;</p>
<hr>
	</div> 
   </div> 

<?php
include "footer.php"
?>




</body>

</html>