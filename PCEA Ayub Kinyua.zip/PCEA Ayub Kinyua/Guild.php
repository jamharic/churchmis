<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Womens guild::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">

<br>
 

<p>&nbsp;</p>
<div id="inner_cont">
<fieldset><legend>Womens Guild</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">
<li>Chairlady 	-	Felista Wanjiru Wanyeki</li>
<li>Secretary 	-	Margaret Njoki Ndung’u</li>
<li>Treasurer	-	Catherine Wangari Mbugua</li>


</ul>
&nbsp;
&nbsp;
This group is for any female aged from 35yrs no upper end on the age.This group teches women to serve God and be good people at their homes.<br>
The Woman’s Guild has a hundred and sixteen (116) full members and 20 followers. It has various activities which ran throughout the year. These include:<ul>
<li>	Observed their week every first week of june</li>
<li>Visited Githiga Children’s Home three </li>
<li>	prepared girls before they joined secondary school by holding a seminar at the beginning of 2015 and followed this up with a mentorship programme for them during the April $ August holiday.</li> 

</ul>
<p style="color:#F00; font-weight:bold;">PROV 31:10-31</P>
</fieldset>



<hr />
</div>
</div>
<?php
include "footer.php"
?>

</div>


</body>

</html>