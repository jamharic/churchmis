<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Dashboard<title>
<link rel="stylesheet" href="../sty/css.css" type="text/css"/>
</head>

<body>
<?php
include_once ("adminheader.php");
?>
<div>
<form action="#" method="POST">
<table>
<tr><td>Name</td><td><input type="text" name="name" placeholder="name" required ></td></tr>
</table>
</form>
</div>

<?php
include_once("../footer.php")
?>
</body>
</html>