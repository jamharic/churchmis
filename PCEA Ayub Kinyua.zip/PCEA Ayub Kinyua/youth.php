<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>youths::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
    <style>
.success{
	color:#F00;
	font-style:italic;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	top:50%;
	margin-left:30%;
	
	}

.error1{
	color:#F00;
	font-style:italic;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	top:50%;
	margin-left:30%;
	
	}

</style>
</head>

<body>

<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">



<p>&nbsp;</p>

<div id="inner_cont">
<fieldset><legend>Youth</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">
<li>Chairman	-	Joseph Kanari Mburu</li>
<li>Secretary	-	Esther Njeri Wainaina</li>
<li>Treasurer	-	Hellen Wambui Macharia</li>
<li>V/Chairman	-	Jesse Huho Mugo</li>
<li>V/Secretary 	-	Maureen Mugethi Ndung’u</li>
</ul>
This group is made up of vibrant young and energetic youn men and women aged from 13yrs-35yrs.The youths are the future leaders and they are trained to serve be moral and and obedient.
With 150 members, 89 of whom are already commissioned, 
</fieldset>
<p>&nbsp;</p>

<hr />
Like our Facebook page<iframe src =<a href="https://web.facebook.com/groups/PCEARAKMCGITH/"> width="50%" height="30%" align="middle">
  

</iframe>
<a href="https://web.facebook.com/groups/PCEARAKMCGITH/"><img src="images/fb.png" height="50px" width="50px"></a><a href="#"><img src="images/is.png" height="50px" width="50px"></a><a href="#"><img src="images/twitter.png" height="50px" width="50px"></a>

<br>
</div>
<div style="right:10%; top:40%;">

<br>



<br>
<br>
</div>

</div>
</br>
</div>
<?php
include "footer.php"
?>
</body>

</html>