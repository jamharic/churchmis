<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Churchschool::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">

<br>
 
	<p>&nbsp;</p>
<div id="inner_cont">
<fieldset><legend>Churchschool</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">

<li>Chairman	-	Michael Kiritu Kamau</li>
<li>Secretary	-	Loise Njoki Kinyua</li>
<li>Treasurer	-	Pauline Wambui Chege</li>
<li>Organizer 	-	Winnie Nyambura Chege</li>
</ul>

Church school is members span from 2yrs of age to 12yrs of age where.Children are taught morality,life skills and to obey Gods commandments among them Love and Obedience to their Children.Parents are asked to bring their children to church for Jesus said let all children come to me.
<br>
The parish church school boasts of 7 teachers and over 300 registered children with many others joining every now and then.  

</fieldset>

<hr />
</div>
</div>
<?php
include "footer.php"
?>
</div>


</body>

</html>