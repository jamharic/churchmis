

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="images/IMG_0242.JPG" alt="1" title="1" id="wows1_0"/></li>
		<li><img src="images/_MG_0167.JPG" alt="2" title="2" id="wows1_1"/></li>
		<li><img src="images/_MG_0123.JPG" alt="3" title="3" id="wows1_2"/></li>
		<li><img src="images/IMG_3716.JPG" alt="4" title="4" id="wows1_3"/></li>
		<li><img src="images/IMG_3261.JPG"alt="5" title="5" id="wows1_4"/></li>
		<li><img src="images/IMG_0300.JPG"alt="6" title="6" id="wows1_5"/></li>
		<li><img src="images/IMG_0385.JPG" alt="7" title="7" id="wows1_6"/></li>
		<li><a href="http://wowslider.com/vi"><img src="data1/images/8.jpg" alt="image slider" title="8" id="wows1_7"/></a></li>
		<li><img src="data1/images/images.jpg" alt="images" title="images" id="wows1_8"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="1"><span><img src="data1/tooltips/1.jpg" alt="1"/>1</span></a>
		<a href="#" title="2"><span><img src="data1/tooltips/2.jpg" alt="2"/>2</span></a>
		<a href="#" title="3"><span><img src="data1/tooltips/3.jpg" alt="3"/>3</span></a>
		<a href="#" title="4"><span><img src="data1/tooltips/4.jpg" alt="4"/>4</span></a>
		<a href="#" title="5"><span><img src="data1/tooltips/5.jpg" alt="5"/>5</span></a>
		<a href="#" title="6"><span><img src="data1/tooltips/6.jpg" alt="6"/>6</span></a>
		<a href="#" title="7"><span><img src="data1/tooltips/7.jpg" alt="7"/>7</span></a>
		<a href="#" title="8"><span><img src="data1/tooltips/8.jpg" alt="8"/>8</span></a>
		<a href="#" title="images"><span><img src="data1/tooltips/images.jpg" alt="images"/>9</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.com/vi">cssslider</a> by WOWSlider.com v8.7</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
</body>
</html>

</body>
</html>