<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Service Times and Church Staff::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>

<div id="pageContent">


<div id="inner_cont">
<table><tr><td><h1>Services and Times</h1>
<p align="justify" >This is How our Week&amp;Sunday programmes are:</p>
<h2>Weekday</h2><ul>
            <li>Wednesday afternoon at 4 PM-6 PM District Prayers</li>
            </ul>
			<h2>Sunday Services</h2>
			<ul>
			<li>Morning Service at 7:30 Am-10:00 AM</li>
			<li>Sunday School at 7:30 Am-10:00 AM</li>
			<li>Main servce at 10:30 AM-1:00 PM</li>

</td>
</tr></table>


<br>

</div> 
</div>

<?php
include "footer.php"
?>


</body>

</html>