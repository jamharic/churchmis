 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upcoming Events::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<div id="pageContent">


<div id="inner_cont">
<h1>Upcoming Church Events</h1>

<div id="message">
<?php 
$con=mysql_connect("localhost","root","");
mysql_select_db("AKM");
if(isset($_POST['share'])){
$insert=mysql_query("insert into message(message)values('".$_POST['message']."')") or die(mysql_error());
if($insert){
echo "Thanks for sharing";
header("refresh:3;events.php");
}
}
?>
<?php
include "conn.php";
$list="";
$sel=mysql_query("select * from youthevents");
$Count=mysql_num_rows($sel);
if($Count>0){
while($row=mysql_fetch_array($sel)){
         $date=$row["date"];	
		 $events=$row["event"];
		 
 
		 $list.="<tr>"; 
		 
		 $list.= "<td><strong>".$date."</strong></td>";
		 $list.="<td>".$events. "</td>";
		 
		 $list.="<tr>";
		 
}

}
else{
	
	echo "NO REQUESTS YET";
	}
?>
<h2 align="center" style="color:#000; background-color:#06F; text-transform:uppercase;">Yearly church Events</h2>
      <table width="87%" border="1" cellpadding="6" cellspacing="0" align="center">
      <tr>
      <th  style="background-color:#06F; color:#000;">Date</th>
      <th style="background-color:#06F; color:#000;">Event</th>
      
      
      </tr>
          <?php echo "$list"  ?> 
          </table>  
</table>
<table><tr><td><p align="center" ><iframe src="https://calendar.google.com/calendar/embed?src=v3b83nq9fndj92t488ljth1ni4%40group.calendar.google.com&ctz=Africa/Nairobi" style="border: 0" width="400" height="400" frameborder="0" scrolling="no"></iframe></td></tr></table>
</div>



</div>
</div>
<?php
include "footer.php"

?>



</body>

</html>