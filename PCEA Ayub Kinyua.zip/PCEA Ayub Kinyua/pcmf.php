<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Groups::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>
<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>
<br>
<div id="pageContent">
 
<br>
 
	
    <p>&nbsp;</p>
<div id="inner_cont">
<fieldset ><legend>Presbyterial Men Fellowship</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">
<li>Chairman	-	Kanyoko Macharia</li>
<li>Secretary	-	Jacob Kabucho Wango</li>
<li>Treasurer	-	Samuel Karanja Muchai</li>
<li>Delegate	-	Simon Kiarie Njoroge<li>
</ul>
&nbsp;
&nbsp;
This a group for males  aged from 35 and no upper limit on age.This group teaches men to take up their responsibilities in the community and be good fathers and husbands and decision makers.<br>
The Parish P.C.M.F. has a total of 114 members with 48 full members, 9 issued with Badges, 21 given cards while 36 are not commissioned. It has also started a junior P.C.M.F. which involves mentoring young men with the intention of eventually absorbing them into the fellowship. </fieldset>
<p>&nbsp;</p>
<hr>
	</div> 
    
</div>
<?php
include "footer.php"
?>




</body>

</html>