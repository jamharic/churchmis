<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gallery</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>



<?php
include_once ("header.php");
?>

<div id="pageContent">
<body>

<div class="gallery" align="center" id="galbdy">
	<h2>Our Church Gallery</h2>
	

	<br />

	

	<div class="preview" align="center">
		<img name="preview" src="images/IMG_3261.JPG" alt=""/>
	</div>
    <br>
<div class="thumbnails">
		<img onmouseover="preview.src=img1.src" name="img1" src="images/_MG_0167.JPG" alt=""/>
		<img onmouseover="preview.src=img2.src" name="img2" src="images/IMG_0388.JPG" alt=""/>
		<img onmouseover="preview.src=img3.src" name="img3" src="images/IMG_3261.JPG" alt=""/>
		<img onmouseover="preview.src=img4.src" name="img4" src="images/IMG_3716.JPG" alt=""/>
		<img onmouseover="preview.src=img5.src" name="img5" src="images/gd.jpg"alt=""/>
	</div><br/>
</div>
</div>
</div>
<?php
include "footer.php"
?>

</div>




</body>
</html>