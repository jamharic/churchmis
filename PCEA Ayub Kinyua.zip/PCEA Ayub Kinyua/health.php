<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Health::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<div id="pageContent">
<div id="inner_cont">
 <br>
 
<p>&nbsp;</p>

<fieldset><legend>Health Board</legend>
<p align="center" style="font-weight:bold; color:#093">Leadership</p>
<ul type="square">
<li>Chairman	-	Hannah Njeri Mwangi</li>
<li>Secretary	-	James Kimani</li>
<li>Treasurer	-	Ben Mwaura</li>
<li>V/Chairperson	-	Geoffrey Njihia Kihiu</li>
<li>V/Secretary	-	Beatrice Muthoni</li>
</ul>
&nbsp;
&nbsp;
<p>Health Board is one group which identifies itself with the Health matter of the entire congregetion.
The Health board membership is sourced from the congregation where each district has a representative.</p>
<p>At the same time they ensure that those people who are from the medical sector constitutes the excutives of the board to ensure proper representation.</p>
<p>The activities involved are<ul>
<li> Organising Medical Camps<li>
<li> Health Talks<li>
<li>First Aid<li>

</ul></p>
.</fieldset>
<p>&nbsp;</p>
<hr>
	</div> 
    </div> 
    

<?php
include "footer.php"
?>




</body>

</html>