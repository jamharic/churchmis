<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Service Times and Church Staff::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>


<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>

</nav>
<div id="pageContent">


<div id="inner_cont">
<p>The most basic part of the church is the Home.Made Father mother and children.After that we have the Districts which are led by elders and this are how our districts are structured,led,named and the number of members</p>

<table align="center">
<tr   style="font-weight:bold; background-color:#999;">
<td>District name</td>
<td>leader</td>
<td>Members</td>
<td>area covered</td>
</tr>
<tr >
<td>Galilea</td>
<td>Elder Lucy Wambui Ng'ang'a</td>
<td>150</td>
<td>Jamaica,Gakoe</td>
</tr>
<tr >
<td>Philadelphia</td>
<td>Mr Harison Githinji Kaguura</td>
<td>200</td>
<td>Githunguri town centre</td>
</tr>
<tr>
<td>Nazareth</td>
<td>Elder Abraham Njuguna Mbugua</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Corithians</td>
<td>Elder Samson Machohi Kamunya</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Bethany</td>
<td>Elder Peter Mbiyu Kamitha</td>
<td>200</td>
<td>Thakwa&amp;Kamwanya</td>
</tr>
<tr>
<td>Judea</td>
<td>Elder Job Muiruri Njuguna</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Jerusalem</td>
<td>Elder Simon Kagwe Kamau</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Jericho</td>
<td>Elder Magret Muembu Macharia</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Ephesus</td>
<td>Elder Leah Wambui Karanja</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Thesalonike</td>
<td>Elder John Kaguma Nguku</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Bethsaida</td>
<td>Elder Mary Wangui Kariuki</td>
<td>200</td>
<td>n/a</td>
</tr>
<tr>
<td>Macedonia</td>
<td>Elder Francis Kago Gitau</td>
<td>200</td>
<td>n/a</td>
</tr>
</table>
<hr>
<p align="center">Sketch Map Of the Districts</p>
<img src="images/scan.png"  height="300px" width="700px" />
<p>&nbsp;</p>
</div> 
</div>

<?php
include "footer.php"
?>


</body>

</html>