<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sermons Corner::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>


<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>

<div id="pageContent">



<br>
<div id="inner_cont">
<fieldset>
<legend><img src="images/new pics.jpg" height="100px" width="100px" /></legend>
<h2 >Pastors Corner</h2>
<table align="left"  width="469px"><tr><td ><?php 
$con=mysql_connect("localhost","root","");
mysql_select_db("AKM");
if(isset($_POST['post'])){
$insert=mysql_query("insert into comments(name,comment)values('".$_POST['name']."','".$_POST['comment']."')") or die(mysql_error());
if($insert){
echo "Thanks for sharing";
header("refresh:3;sermon.php");
}
}

?>
<?php
$sel=mysql_query("select * from sermon");
while($row=mysql_fetch_array($sel)){
?>
<tr><td><?php echo $row['sermons']."<br/>";?></td></tr>
<?php } ?>

</td></tr></table><br>
</fieldset>
<h2>&nbsp;</h2>
<h2>&nbsp;</h2>
<h2>&nbsp;</h2>


<br>

<a href="login/index.php"><img src="images/clickhere.jpg"></a>Admin Login
<br>
<table align="center"><tr><td>
<a href="pdf/sp.pdf">
<img src="images/pdf.png" height="50px" width="50px" align="center" \></a>Download last sunday sermon</td></tr></table>
</div>
</div>

<?php
include "footer.php";
?>


</body>

</html>