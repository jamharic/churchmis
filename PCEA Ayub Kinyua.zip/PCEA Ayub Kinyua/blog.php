 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upcoming Events::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>
<div id="pageContent">


<div id="inner_cont">
<p><h1>Hi Welcome To Our Blog</h1><img src="images/pcea.png" height="50px" width="50px" /></p>

<div id="message">
<p align="center">Share +</p>
<?php
include_once "conn.php";
if(isset($_POST['blogger'])&&($_POST['comment'])){
	
	$name=$sermon=preg_replace('#[^A-Za-z0-9\s]#i','',$_POST["blogger"]);
	$comm=$sermon=preg_replace('#[^A-Za-z0-9\s\n]#i','',$_POST["comment"]);
	
	$insert1=mysql_query("insert into comments (name,comment,d_added)values('".$name."','".$comm."',now())") or die(mysql_error());
	
	}
	else{
		
		echo "Your Post wasn't  Succesful";
		
		}
header("location;blog.php");
?>
<form method="POST" action="blog.php">
<table>
<tr><td>Name</td><td><input type="text" name="blogger" Required></td></tr></tr>
<tr><td>Comment</td><td><textarea name="comment" required="required" cols="30" rows="10"></textarea></td></tr>
<tr><td><input type="submit" name="post" value="POST" />
</table>
</form>
<h4 align="center" style="color:#000; background-color:#06F; text-transform:uppercase;">Our Chat Room</h4>
<?php
include_once "conn.php";


$sel=mysql_query("select * from comments ORDER BY id DESC limit 20");
while($row=mysql_fetch_array($sel)){
?>
      
<tr><td><?php echo $row['name']." " ."says"."<br/>". $row['comment']."<br/>". $row['d_added']."<hr/>"."<br/>";?></td></tr>
<?php } 
		 
?>






</div>
</div>
</div>
<?php
include "footer.php"

?>



</body>

</html>