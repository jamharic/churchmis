<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rev Ayub Kinyua Mem Church::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />

</head>

<body>
<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>

<?php
include_once("banner.php")
?>

<br>
<div id="pageContent">

<br>


<div id="inner_cont">
<div>
<h1>Ayub Kinyua Memorial Church</h1>
Githunguri Parish is a one congregation Parish that came into existence on the 23rd September, 2013.  It is located in Githunguri Town just behind Githunguri Township Primary School and adjacent to the Githunguri Sub-County government offices. Both its congregation {P.C.E.A. Rev. Ayub Kinyua Memorial Church} and Parish offices are located within the same compound next to Githunguri Presbytery office. It boarders New Kahunira Parish in the West, Kambui Presbytery in the East, and the new Kiamathare Parish in the South. Until recently, a part of Kiamathare Parish was located within its boarders but the new boundary located at Kiairia river, curved out a large section leaving very little room for future expansion. .<br>
<h4>Mision:</h4><p style="color:#F00;">Be holy for God is holy (1Peter 1:16).</p>
<a href="aboutus.php" class="links">Read More>></a>
</div>
 

</div>
</div>
&nbsp;
&nbsp;


<?php

include "footer.php"
?>

</body>

</html>