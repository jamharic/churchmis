<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>about us::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>


<nav class="fixed-nav-bar">

<?php
include_once ("header.php");
?>
</nav>
<div id="pageContent">
<br>
<br>
<div id="inner_cont">
Locate Us......
<br>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false">
</script><div style="overflow:hidden;height:300px;width:600px;border:#999 1px solid; margin-left:100px;">
<div id="gmap_canvas" style="height:300px;width:600px;border:#999 1px solid;"></div>
<style>#gmap_canvas img{max-width:none!important;background:none!important}</style>
<a class="google-map-code" href="http://wordpress-themes.org" id="get-map-data">templates</a></div>
<script type="text/javascript"> function init_map(){var myOptions = {zoom:17,center:new google.maps.LatLng
(-1.05511010791075,36.78077323997036),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map
(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker
({map: map,position: new google.maps.LatLng(-1.05511010791075, 36.78077323997036)});
infowindow = new google.maps.InfoWindow({content:"<b>k</b><br/>Ayub Kinyua Church<br/> Githunguri town" })
;google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open
(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
<br>
<br>
<fieldset><legend>MOTTO</legend>
Be holy for God is holy (1Peter 1:16)</fieldset><br>
<fieldset><legend>VISSION</legend>A church developing/nurturing a holistic person for God’s glory and eternal
life</fieldset><br>
<fieldset><legend>MISSION</legend>To engage congregants in bible study, teaching, preaching and evangelizing
for their wellbeing</fieldset><br>
<fieldset><legend>CORE VALUES</legend>
<ul type="circle">
<li>Holiness and spirituality</li>
<li>Service to God and mankind</li>
<li>Teamwork and synergism</li>
<li>Humility and kindness</li>
<li>Integrity and accountability</li>
</ul>
</fieldset>



</h3>




<table align="center"><tr><td><a href="pdf/sp.pdf">
<img src="images/pdf.png" height="50px" width="50px" align="center" \></a>View our church Strategic Plan</td></tr></table>
</div>
</div>


<?php

include "footer.php" 
?>


</body>

</html>