<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Service Times and Church Staff::</title>
<link href="images/pcea.jpg" rel="icon" type="image/icon"/>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>



<nav class="fixed-nav-bar">
<?php
include_once ("header.php");
?>
</nav>

<div id="pageContent">


<div id="inner_cont">
<h2>CHURCH SERVING TEAM</h2>
<fieldset>
<legend><img src="images/new pics.jpg" height="100px" width="100px" /></legend>
<p>REV HARRISON WACHIRA</p>
<p>
Current serving Githunguri Parish minister.Humble,loving,energetic and social Man of God who have also served at Gatundu parish.
</p>

</fieldset>
<fieldset>
<legend><img src="images/IMG_2207.JPG"height="100px" width="100px" /></legend>
<p>MRS MARY WANGUI KARIUKI</p>
<p>
Current serving Githunguri Parish Chairlady.She also serves with the womens guild.She is social,humble and loving woman of God.
</p>

</fieldset>
<p>Elders serving from  year 2014-2015</p>

<table align="center">
<tr   style="font-weight:bold;background-color:#06F; color:#000;">
<td>Elder Name</td>
<td>Date Ordained</td>
<td>District</td>

</tr>
<tr >
<td>Elder Abraham Njuguna</td>
<td>16/10/2011</td>
<td>Nazareth</td>

</tr>
<tr >
<td>Elder Lucy Wambui Nganga</td>
<td>3/9/1996</td>
<td>Galillee</td>

</tr>
<tr >
<td>John Kaguma Nguku</td>
<td>10/2007</td>
<td>Thesalonike</td>

</tr>
<tr >
<td>Job Muiruri Njuguna	</td>
<td>16/10/2011</td>
<td>Judea</td>

</tr>
<tr >
<td>Leah Wambui Karanja	</td>
<td>17/12/2000</td>
<td>Ephesus</td>
</tr>
<tr>
<td>Peter Mbiyu Kamitha</td>
<td>17/10/2004</td>
<td>Bethany</td>

</tr>
<tr >
<td>Samson Machohi Kamunya</td>
<td>16/10/2011</td>
<td>Jerusalem</td>

</tr>
<tr >
<td>Mary Wangui Kariuki</td>
<td>22/11/2009</td>
<td>Bethsaida</td>

</tr>
<tr>
<td>Margaret Mwembu Macharia </td>
<td>21/09/2014</td>
<td>Jericho</td>

</tr>
<tr >
<td>Harrison Kaguura Githinji</td>
<td>4/12/2009</td>
<td>Philadelphia</td>

</tr>
<tr >
<td>Simon kagwe kamau</td>
<td>20/12/2015</td>
<td>Corinth</td>

</tr>
<tr >
<td>Francis kago gitau</td>
<td>20/12/2015</td>
<td>Macedonia</td>

</tr>

<tr >
<td>Keziah Wangui Gathecha</td>
<td>3/11/1996</td>
<td>Retired</td>

</tr>
<tr >
<td>Joseph Wanyeki Gitau</td>
<td>09/10/1980</td>
<td>Retired</td>

</tr>
<tr >
<td>Ruth Wambui Wairia</td>
<td>0/0/1968</td>
<td>Retired</td>

</tr>
</table>
<p>&nbsp;</p>
</div> 
</div>

<?php
include "footer.php"
?>


</body>

</html>