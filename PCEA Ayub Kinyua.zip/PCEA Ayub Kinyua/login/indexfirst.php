	<?php 
$con=mysql_connect("localhost","root","");
mysql_select_db("AKM");?>

<?php
if (!$con){
echo "not connect";

}
session_start();
if(isset($_SESSION["manager"])){
	header("location:indexI.php");
	exit();
	}
	?>

<html>
<head>
<title>Admin Log In</title>
<link rel="stylesheet" href="../style/style.css" type="text
/css" media="screen"/>
<style> #form {
    width: 250px;
    padding: 20px;
    border: 1px solid #270644;
    
    background:  -moz-linear-gradient(19% 75% 90deg,#4E0085, #963AD6);
    background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#963AD6), to(#4E0085));
color: #FFFFFF;
}
.error{
	color:red;
	font-style:italic;
	font-weight:bold;
}
</style>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
 <body>
 <div id="mainWrapper" align="center" style="">
  <table border="0" width="1000px">
<tr>
<td>

</td>
</tr>
</table>
   <div id="pageContent"><br/>
     <div id="form">
	 <?php
if(isset($_POST["username"])&&isset($_POST["password"])){
		
		$manager=preg_replace('#[^A-Za-z0-9]#i','',$_POST["username"]);
		$password=preg_replace('#[^A-Za-z0-9]#i','',$_POST["password"]);
        
$sql=mysql_query("SELECT id FROM admin WHERE username='".$manager."' AND password='".$password."' LIMIT 1" );

$existCount=mysql_num_rows($sql);
if($existCount == 1){
	while($row=mysql_fetch_array($sql)){

$id=$row["id"];
  }
		
		$_SESSION["id"]=$id;
	    $_SESSION["manager"]=$manager;
		$_SESSION["password"]=$passowrd;
		header("location:indexI.php");
		
}
else{
				?>
				<span class="error"><?php echo ucwords(" Sorry Wrong Username or Password!!!!"); ?></span>
				<?php 
				}
}
	
?>
       <h2>Please Log In </h2>
       <form id="form1"name="form1"method="post"action="index.php">
          User Name:<br/>
           <input name="username"type="text"id="username"/>
           <br/><br/>
           Password:<br/>
           <input name="password"type="password"id="password"/>
           <br/><br/><br/>
             <input type="submit"name="button"id="button"value="Log In >>"/>
             <a href="../index.php" class="links">Home </a> 
         </form>
         <p>&nbsp;</p>  
         <a href="../index.php">Home </a>   
</div>
<br/><br/><br/>
</div>

   <table border="0" width="1000px">
<tr>
<td>

</td>
</tr>
</table>
 </div>
 </body>
 </html>