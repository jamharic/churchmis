<?php
include_once("session.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Dashboard</title>
<link rel="stylesheet" href="css.css" type="text/css">


</head>

<body onLoad="hideloader()">
<div id="load"></div>
<?php
include_once ("adminheader.php");
?>
<br>
<table><tr><td align="left">
<section id="lmenu" class="link">
<h1 align="center">Admin Menu</h1>
<ul type="square"><br>
<li><a href="dashboard3.php">Manage Sermons</a></li><br>
<li><a href="dashboard.php">Add Events</a></li><br>
<li><a href="dashboard1.php">Add Youths Events</a></li><br>
<li><a href="dashboard2.php">Add Members</a></li><br>
</ul>
</section></td>
<td align="right"><section id="rmenu">
<fieldset>
<fieldset style="border-color:#00C; border-radius:20px;width:250px; heigth:100px;margin-left:20px;">

<legend><img src="images/Admin-icon.png"/>
</legend>
<h2 style="color:#F00; font-style:italic;" >Please Register Here*</h2>
<br>
<?php
include_once "../conn.php";

function checkempty(){
	if (empty($_POST['Name'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please input name!!!!"); ?></span>
				<?php 
	}
	if (empty($_POST['email'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please input email number!!!!"); ?></span>
				<?php 
	}
	if (empty($_POST['phone'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please input phone number!!!!"); ?></span>
				<?php 
	}
	if (empty($_POST['DOB'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please input Date Of birth!!!!"); ?></span>
				<?php 
	}
	if (empty($_POST['District'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please input a valid District!!!!"); ?></span>
				<?php 
	}
	}
  if(isset($_POST['submit'])){
$name=preg_replace('#[^A-Za-z]#i','',$_POST["Name"]);
$email=($_POST["email"]);
$phone=preg_replace('#[^0-9]#i','',$_POST["phone"]);
$dob=($_POST["DOB"]);
$district=preg_replace('#[^A-Za-z]#i','',$_POST["district"]);

	$query=mysql_query("insert into district (name,email,phone,dob,district) values ('".$name."','".$email."','".$phone."','".$dob."','".$district."')");
	
	?>
				<span class="success"><?php echo ucwords(" Registered Succesfully!!!!"); ?></span>
				<?php 
				}
				else{
				
				checkempty();
				
				}
	
 

?>
<form action="#" method="post">
<table>
<tr>
<td>FullNames</td><td><input type="text" name="Name" size="20" required></td></tr>
<tr>
<td>Email Address</td><td><input type="email" name="email" size="20" required></td></tr>
<tr>
<td>Phone Number</td><td><input type="text" name="phone" size="20" required></td></tr>
<tr>
<td>Date of Birth</td><td><script src="login/datetimepicker_css.js"></script>

    <input type="Text" id="demo1"  name="DOB"/ size="20" required>
        <img src="login/images/cal.gif" onclick="javascript:NewCssCal ('demo1','yyyyMMdd','','','','','')"  style="cursor:pointer"/></td></tr>
<tr>
<td>District</td><td><select name="district" required>
<option value="Galilea">Galilea</option>
<option value="Philadelphia">Philadelphia</option>
<option value="Nazareth">Nazareth</option>
<option value="Corithians">Corithians</option>
<option value="Bethany">Bethany</option>
<option value="Judea">Judea</option>
<option value="Jerusalem">Jerusalem</option>
<option value="Jericho">Jericho</option>
<option value="Ephesus">Ephesus</option>
<option value="Thesalonike">Thesalonike</option>
<option value="Bethsaida">Bethsaida</option>
<option value="Macedonia">Macedonia</option

></select>

</td></tr>
<tr><td><input type="submit" name="submit" value="register"></td></tr>
</tr></table>
</form>

</fieldset>

<br>
</fieldset>
</section>
</td></tr></table>
 
<?php
include_once("../footer.php")
?>
</div>
</body>
</html>