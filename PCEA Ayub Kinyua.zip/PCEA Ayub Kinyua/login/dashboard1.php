<?php
include_once("session.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Dashboard</title>
<link rel="stylesheet" href="css.css" type="text/css">


</head>

<body onLoad="hideloader()">
<div id="load"></div>
<?php
include_once ("adminheader.php");
?>
<br>
<table><tr><td align="left">
<section id="lmenu" class="link">
<h1 align="center">Admin Menu</h1>
<ul type="square"><br>
<li><a href="dashboard3.php">Manage Sermons</a></li><br>
<li><a href="dashboard.php">Add Events</a></li><br>
<li><a href="dashboard1.php">Add Youths Events</a></li><br>
<li><a href="dashboard2.php">Add Members</a></li><br>
</ul>
</section></td>
<td align="right"><section id="rmenu">
<fieldset>
<form action="#" method="POST">
<table align="center">
<tr><th align="center">+ Upcoming Events</th></tr>
<?php
include_once "../conn.php";
if(empty($_POST['date'])||empty($_POST['details']))
{
	echo "Please fill in all the fields";
	
}
else if(isset($_POST['date'])&& isset($_POST['details'])){
	$date=($_POST["date"]);
	$details=($_POST["details"]);
	$youths=mysql_query("insert into youthevents(date,event) values('".$date."','".$details."')");
	
	}
?>
<form action="dashboard1.php" method="post"><table>
<th>Youths updates</th>
<tr><td>Event Dates</td><td>
<script src="datetimepicker_css.js"></script>

    <input type="Text" id="demo1"  name="date"/>
        <img src="images/cal.gif" onclick="javascript:NewCssCal ('demo1','yyyyMMdd','','','','','')"  style="cursor:pointer"/>
</td></tr>
<tr><td>Event details</td><td><textarea name="details"></textarea> </td></tr>
<tr><td><input type="submit" name="update" id="file" value="add Event"/></td></tr>
</table>
</form>


<br>
</fieldset>
</section>
</td></tr></table>
 
<?php
include_once("../footer.php")
?>
</div>
</body>
</html>