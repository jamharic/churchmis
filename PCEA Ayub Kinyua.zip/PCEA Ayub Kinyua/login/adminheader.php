<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="../sty/css.css" type="text/css">
</head>

<body>
<div id="head">
<table><tr><td><img src="../images/pcea.png" width="40px" height="40px"></td><td><?php echo $Login_user;?></td><td align="right"><a href="logout.php">Sign Out</td></tr></table>
</div>
</body>
</html>