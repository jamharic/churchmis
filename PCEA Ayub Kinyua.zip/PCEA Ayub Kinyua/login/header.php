<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css" />

 <style type="text/css">
<!--

ul{
				list-style-type: none;
				font-size:9pt;
  }
ul#navmenu li{
	 width: 125px;
	 text-align:center;
	 position:relative;
	 float:left;
	 margin-right:4px;
			 }
ul#navmenu a{
     text-decoration:none;
	 display:block;
	 width: 125px;
	 height: 25px;
	 line-height:25px;
	 background-color:#F00;
	 border:1px solid #CCC;
	 
}	
ul#navmenu .sub1 a{
     margin-top:3px;
	 opacity:1;	
}
ul#navmenu .sub2 a{
     margin-left:8px;	
}
ul#navmenu li:hover > a{
     background-color:#00F;	
}
ul#navmenu li:hover a:hover{
     background-color:#00F;	
}
ul#navmenu ul.sub1{
     display:none;
	 position:absolute;
	 top:26px;
	 left:0px;
}
ul#navmenu ul.sub2{
     display:none;
	 position:absolute;
	 top:0px;
	 left:85px;
}
ul#navmenu li:hover .sub1{
     display:block;
}
ul#navmenu .sub1 li:hover .sub2{
     display:block;
}
.darrow{
font-size:9pt;
position:absolute;
top:5px;
right:4px;
color:#000;
}
.rarrow{
font-size:9pt;
position:absolute;
top:7px;
right:4px;
color:#000;
}
-->
</style>
</head>
<body>
<div id="pageHeader">
<img src="../images/pcea.png" height="50px" width="50px"/><div id="special">PCEA GITHUNGURI PARISH</div>
   <table>
     
     <tr>
     
       <td height="0" colspan="3" valign="top"><ul id="navmenu">
  <li><a href="index.php">home</a></li>
 <li><a href="logout.php">Logout</a>
  </li>
 
  <
 </ul> 
 </td>
     </tr>
   </table>
 </div>
 </body>
 </html>