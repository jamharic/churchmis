<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Youthdashbord::</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<link href="../style.css" rel="stylesheet" type="text/css" />
<link href="../style1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");

?>
</nav>
	
    <div id="pageContent">
	<div id="inner_cont">			
	


   <table width="700" border="0" cellpadding="0" cellspacing="10" class="phototable"><tr><td>
	
	<h1 style="color:#F00;Font-family:papyrus;"> Youth Admins Dashboard</h1></td></tr></table>




<?php
include_once "..\conn.php";
if(empty($_POST['date'])||empty($_POST['details']))
{
	echo "Please fill in all the fields";
	
}
else if(isset($_POST['date'])&& isset($_POST['details'])){
	$date=($_POST["date"]);
	$details=($_POST["details"]);
	$youths=mysql_query("insert into youthevents values('".$date."','".$details."')");
	
	}
?>
<form action="index1.php" method="post"><table>
<th>Youths updates</th>
<tr><td>Event Dates</td><td>
<script src="datetimepicker_css.js"></script>

    <input type="Text" id="demo1"  name="date"/>
        <img src="images/cal.gif" onclick="javascript:NewCssCal ('demo1','yyyyMMdd','','','','','')"  style="cursor:pointer"/>
</td></tr>
<tr><td>Event details</td><td><textarea name="details"></textarea> </td></tr>
<tr><td><input type="submit" name="update" id="file" value="add Event"/></td></tr>
</table>
</form>


<br>

<p>&nbsp;</p>
<p>&nbsp;</p>



<hr />


</div>


</div>


</body>

</html>