<?php 
session_start();
if(isset($_SESSION["manager"])){
	header("location:dashboard.php");
	exit();
	}
	?>
<?php
if(isset($_POST["email"])&&isset($_POST["pswd"])){
		
		$manager=preg_replace('#[^A-Za-z0-9]#i','',$_POST["email"]);//filter everything but numbers and letters
		$password=preg_replace('#[^A-Za-z0-9]#i','',$_POST["pswd"]);//filter everything but numbers and letters
include "../conn.php";
$sql=mysql_query("SELECT id FROM admin WHERE admin='$manager' AND password='$password' LIMIT 1");//query to ensure user is in database
$existCount=mysql_num_rows($sql);
if($existCount == 1){//evaluate the count
	while($row=mysql_fetch_array($sql)){
		$id = $row["id"];
		}
		$_SESSION["id"]=$id;
	    $_SESSION["manager"]=$manager;
		$_SESSION["password"]=$password;
		header("location:dashboard.php");
		exit();
}
else{
	echo"That information is incorrect,try again!<a href='index.php'> Click Here.</a>";
	exit();
}
	}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Login</title>
<link rel="stylesheet" href="css.css" type="text/css">
</head>

<body>
<div id="titl">
<p align="center"><img src="../images/pcea.png" width="50px" height="50px"> Site Admin Login   </p>
&nbsp;
</div>
<div id="logform">
<fieldset>
<legend align="center">
<img src="images/login_lock.png" width="70px" height="70px">
</legend>
<form action="index.php" method="POST" >
<table>
<tr><td>Username</td><td><input type="text" name="email" placeholder="Username"><br></td></tr>
<tr><td>Password</td><td><input type="password" name="pswd" placeholder="******" ></td></tr>
<tr><td><input type="submit" name="sbmt" value="login"/></td></tr>
</table>
</form>
<a href="../index.php">Return To The Site</a>
</fieldset>
</div>
</body>
</html>