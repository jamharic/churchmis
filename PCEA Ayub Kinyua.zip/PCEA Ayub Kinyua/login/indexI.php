<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>welcome::</title>
<link rel="stylesheet" href="../style.css" type="text
/css" media="screen"/>;
</head>

<body>
<?php 
session_start();
if(!isset($_SESSION["manager"])){
	header("location:index.php");
	exit();
	}
$managerID=preg_replace('#[^0-9]#i','',$_SESSION["id"]);//filter everything but numbers
$manager=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["manager"]);//filter everything but numbers and letters
$password=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["password"]);//filter everything but letters
include"../conn.php";
$sql=mysql_query("SELECT id FROM admin WHERE  id='$managerID' AND username='$manager' AND password='$password' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount == 0){
	header("location:../index.php");
	exit();
		}
?>
 
 


 
 <div id="mainWrapper" align="center">
   <table border="0" width="1000px">
<tr>
<td>
<nav class="fixed-nav-bar">
<?php include_once("header.php");?>
</nav>
</td>
</tr>
</table>
   <div id="pageContent"><br/>
     <div align="left" style="margin-left:24px;">
     <h2>Hello Secretary, what would you like to do today?</h2> 
       <p><a href="index1.php">Church Page</a><br/></p>
       <p><a href="indexy.php">Youth Page</a><br/></p>
      
     </div>
</div>
  
<?php include_once("../footer.php");?>

 </div>
</body>
 </html>
</body>
</html>