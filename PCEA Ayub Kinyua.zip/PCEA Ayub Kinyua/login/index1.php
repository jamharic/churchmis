<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard::</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<link href="../style.css" rel="stylesheet" type="text/css" />
<link href="../style1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
</head>

<body>

<nav class="fixed-nav-bar">
<?php
include_once ("header.php");

?>
</nav>
	
    <div id="pageContent">
	<div id="inner_cont">			
	


   <table width="700" border="0" cellpadding="0" cellspacing="10" class="phototable">
	
	<h1 style="color:#F00;Font-family:papyrus;">Admins Dashboard</h1>


<?php 
$con=mysql_connect("localhost","root","");
mysql_select_db("AKM");
if(isset($_POST['share'])){
$message=preg_replace('#[^A-Za-z0-9]#i','',$_POST["message"]);
$insert=mysql_query("insert into message(message)values('".$message."')") or die(mysql_error());

if($insert){
?>
				<span class="alert"><?php echo ucwords(" Thanks For Sharing"); ?></span>
				<?php 
header("refresh:3;index1.php");
}
}
elseif(isset($_POST['share1'])){
	
	
	$sermon=preg_replace('#[^A-Za-z0-9]#i','',$_POST["sermon"]);
	$insert1=mysql_query("insert into sermon(sermon)values('".$sermon."')") or die(mysql_error());
	
	?>
				<span class="alert"><?php echo ucwords(" Thanks For Sharing"); ?></span>
				<?php 
header("refresh:3;index1.php");
}
	
?>
<table>

<?php
$list="";
$select=mysql_query("select * from request");
$Count=mysql_num_rows($select);
if($Count>0){
while($row=mysql_fetch_array($select)){
         $email=$row["email"];	
		 $enquiry=$row["enquiry"];
		 $yes=$row["yes"];
		 $no=$row["no"];
 
		 $list.="<tr>"; 
		 $list.="<td>".$email."</td>"; 
		 $list.= "<td><strong>".$enquiry."</strong></td>";
		 $list.="<td>".$yes. "</td>";
		 $list.="<td>".$no. "</td>";
		 $list.="<tr>";
		 
}

}
else{
	
	echo "NO REQUESTS YET";
	}
?>
<?php
if(isset ($_GET['delsermon'])){
	
	$del=mysql_query("delete from sermon LIMIT 1");
	echo "deleted";
	
	}
elseif(isset($_GET['delete']))
{
	
	$delete=mysql_query("delete from message ");
	echo "deleted";
	
	}
?>

</table>
<div align="left" style="margin-left:24px;">
      <h2 align="center" style="color:#F00; text-transform:uppercase;">Requsts&amp;Enquires</h2>
      <table width="87%" border="1" cellpadding="6" cellspacing="0" align="center">
      <tr>
      <th bgcolor="#99CCFF" align="left">Email addresse</th>
      <th bgcolor="#99CCFF" align="left">Request</th>
      <th bgcolor="#99CCFF" align="left">Subscribed</th>
      <th bgcolor="#99CCFF" align="left">Not subscribed</th>
      
      </tr>
          <?php echo "$list"  ?> 
          </table>   
          
</div>
<div style="margin-right:20%">
<?php
if(empty($_POST['date'])||empty($_POST['details']))
{
	echo "Please fill in all the fields";
	
}
else if(isset($_POST['date'])&& isset($_POST['details'])){
	$date=($_POST["date"]);
	$details=($_POST["details"]);
	$youths=mysql_query("insert into youthevents values('".$date."','".$details."')");
	
	}
?>
<form action="index1.php" method="post"><table align="right">
<th>Youths updates</th>
<tr><td>Event Dates</td><td>
<script src="datetimepicker_css.js"></script>

    <input type="Text" id="demo1"  name="date"/>
        <img src="images/cal.gif" onclick="javascript:NewCssCal ('demo1','yyyyMMdd','','','','','')"  style="cursor:pointer"/>
</td></tr>
<tr><td>Event details</td><td><textarea name="details"></textarea> </td></tr>
<tr><td><input type="submit" name="update" id="file" value="add Event"/></td></tr>
</table>
</form>
</div>
<form action="" method="post" action="index1.php">
<table>
<tr><td><br>please share the calendar dates<br>
<textarea name="message" id="message" cols="30" rows="10" required></textarea>
</td></tr><tr><td>
<input type="submit" id="share" name="share" value="share" />
</td></tr><table>
</form>
<form action="#" method="GET">
<input type="submit" name="delete" value="delete Old Events" />
</form>
<br>
<form action="" method="post" action="index1.php"><table>
<tr><td><br>please share the sermon<br>
<textarea name="sermon" id="sermon" cols="30" rows="10" required></textarea>
</td></tr>

<tr><td>
<input type="submit" id="share" name="share1" value="share" />
</td></tr>
</table>
</form>
<form action="#" method="GET">
<input type="submit" name="delsermon" value="delete Sermon" />
</form>
<a href="addadmin.php">Add Admin+</a>
</table>

<p>&nbsp;</p>
<p>&nbsp;</p>



<hr />


</div>


</div>


</body>

</html>