<?php
session_start();
if(!isset($_SESSION["id"])){
	header("location:index.php");
	exit();
	}



 include_once ("../conn.php");

  $loggedin=$_SESSION['id'];
$query="select * from admin where id= $loggedin ";
$query_run=mysql_query($query);
while($row=mysql_fetch_assoc($query_run))
{
$Login_user= $row['admin'];		
		
		
		
}
 
 ?>