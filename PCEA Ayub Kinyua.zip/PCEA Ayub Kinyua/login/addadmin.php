<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
.success{
	color:#F00;
	font-style:italic;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	top:50%;
	margin-left:30%;
	
	}

.error1{
	color:#F00;
	font-style:italic;
	font-family:Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif;
	top:50%;
	margin-left:30%;
	
	}

</style>
</head>

<body>
<div style="margin-right:10%;margin-top:20%;margin-left:10%;">
<fieldset style="border-color:#00C; border-radius:20px;">
<legend><img src="../images/Admin-icon.png"/>
</legend>
<h2 style="color:#F00; font-style:italic;" >Please Register Here*</h2>
<br>
<form action="#" method="post">
<table style="margin-right:100px"><tr>
<td>Email Address</td><td><input type="text" name="email"></td></tr>
<tr>
<td>Username</td><td><input type="text" name="username"></td></tr>
<tr>
<td>password</td><td><input type="password" name="password"></td></tr>
<tr>
<td>confirm Password</td><td><input type="password" name="conpass"></td></tr>
<tr><td><input type="submit" name="submit" value="register"></td></tr>
</tr></table>
</form>
<?php
include_once("../conn.php");


	if (empty($_POST['email'])&&empty($_POST['username'])&&empty($_POST['password'])&&empty($_POST['conpass'])){
	
	
	?>
				<span class="error1"><?php echo ucwords(" please fill in all the fields!!!!"); ?></span>
				<?php 
	}
 else if(isset($_POST['submit'])){
$email=($_POST["email"]);
$username=($_POST["username"]);
$password=($_POST["password"]);
$conpass=($_POST["conpass"]);
	$query=mysql_query("insert into admin (username,password,email) values ('".$username."','".$password."','".$email."')") or die(mysql_error());
	
	?>
				<span class="success"><?php echo ucwords(" Registered Succesfully!!!!"); ?></span>
				<?php 
				}
	


?>
</fieldset>
</div>
</body>
</html>